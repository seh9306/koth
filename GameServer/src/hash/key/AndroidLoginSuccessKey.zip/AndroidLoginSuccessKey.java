package hash.key;

public class AndroidLoginSuccessKey {

}
